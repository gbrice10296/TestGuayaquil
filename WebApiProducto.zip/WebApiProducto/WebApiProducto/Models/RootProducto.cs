﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiProducto.Models
{
    public class RootProducto
    {
        [Key]
        public int idrootproducto { get; set; }
        public string transaccion { get; set; }
        public string tipo { get; set; }
    }
}
