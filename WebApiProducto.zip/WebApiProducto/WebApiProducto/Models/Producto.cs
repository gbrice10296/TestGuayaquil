﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiProducto.Models
{
    public class Producto
    {

        public int idproducto { get; set; }
        public int CodProducto { get; set; }
        public string descripcion { get; set; }
        
        public decimal precio { get; set; }

        public bool estado { get; set; }
        public string detalle { get; set; }
        public string imagen { get; set; }

        public string UsuarioCrea { get; set; }

        public DateTime FechaCrea { get; set; }

        public string comentario { get; set; }

        public string transaccion { get; set; }

        public int tipo { get; set; }
      
            
    }
}
