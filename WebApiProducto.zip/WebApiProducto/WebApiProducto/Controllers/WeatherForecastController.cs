﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiProducto.Models;

namespace WebApiProducto.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
            {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }


        //[HttpGet]
        //public IEnumerable<Producto> GetProducto()
        //{
        //    var rng = new Producto();
        //    return Enumerable.Range(1, 5).Select(idproducto => new Producto
        //    {
             
        //        idproducto=44,
        //        descripcion= "TERNO 2 PIEZAS SECO",
        //        precio = Convert.ToDecimal(8.50),
        //        estado=true,
        //        detalle= "El terno de 2 piezas incluye la leva y el pantalón, el lavado es en seco, se entrega en armador y con su respectiva funda",
        //        imagen = "seco-terno2.jpg",
        //        UsuarioCrea="Sys",
        //        FechaCrea=DateTime.Now
        //    })
        //    .ToArray();
        //}

    }
}
