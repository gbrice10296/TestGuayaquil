﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebApiProducto.Models;

namespace WebApiProducto.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductoController : Controller
    {
        // GET: api/<UserController>
        [HttpGet("consultaproducto")]
        public ActionResult consultaproducto(int id, string comenta)
        {
          
            var productos = from Producto in productos1()
                           where Producto.idproducto.Equals(id)
                           select Producto;
         
            return Ok(productos.ToList());
        }


        // GET: api/<UserController>
        [HttpGet("productos")]
        public ActionResult productos(string transaccion, int tipo)
        {

            var trans = transaccion.ToUpper();
            var productos = from Producto in productos1()
                            where Producto.transaccion.Equals(trans) && Producto.tipo.Equals(tipo)
                            select Producto;

            return Ok(productos.ToList());
        }




        



        [NonAction]
        public List<Producto> productos1()
        {
            return new List<Producto>
            {
                new Producto
                {
                       idproducto=44,
                    descripcion= "TERNO 2 PIEZAS SECO",
                    precio = Convert.ToDecimal(8.50),
                    estado=true,
                    detalle= "El terno de 2 piezas incluye la leva y el pantalón, el lavado es en seco, se entrega en armador y con su respectiva funda",
                    imagen = "seco-terno2.jpg",
                    UsuarioCrea="Sys",
                    FechaCrea=DateTime.Now,
                    comentario="",
                    transaccion="GENERICO",
                    tipo=4
                },
                new Producto
                {
                  idproducto=45,
                descripcion= "TERNO 3 PIEZAS SECO",
                precio = Convert.ToDecimal(9.5),
                estado=true,
                detalle= "El terno de 3 piezas incluye la leva, el chaleco y el pantalón, el lavado es en seco, se entrega en armador y con su respectiva funda",
                imagen = "seco-terno3.jpg",
                UsuarioCrea="Sys",
                FechaCrea=DateTime.Now,
                  comentario="",
                  transaccion="GENERICO",
                    tipo=4
                },
                new Producto
                {
                  idproducto=46,
                descripcion= "LEVA SECO",
                precio = Convert.ToDecimal(4.75),
                estado=true,
                detalle= "La leva es lavada en seco  con el mayor cuidado de la prenda, se entrega en armador y con su respectiva funda",
                imagen = "seco-leva.jpg",
                UsuarioCrea="Sys",
                FechaCrea=DateTime.Now,
                  comentario="",
                  transaccion="",
                    tipo=0
                }

            };
        }


        // GET api/values  
        [HttpPost, Route("login")]
        public IActionResult Login([FromBody] LoginModel user)
        {
            if (user == null)
            {
                return BadRequest("Invalid request");
            }

            if (user.email == "danielsilvaorrego@gmail.com" && user.Password == "89e495e7941cf9e40e6980d14a16bf023ccd4c91")
            {
                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("KeyForSignInSecret@1234"));
                var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

                var tokeOptions = new JwtSecurityToken(
                    issuer: "http://localhost:2000",
                    audience: "http://localhost:2000",
                    claims: new List<Claim>(),
                    expires: DateTime.Now.AddMinutes(30),
                    signingCredentials: signinCredentials
                );

                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                return Ok(new { Token = tokenString });
            }
            else
            {
                return Unauthorized();
            }
        }

    }
}

