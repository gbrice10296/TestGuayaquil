﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApiProducto.Models;

namespace WebApiProducto.Data
{
    public class AppDbContext :DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> option ): base(option)
        {

        }
        public DbSet<Producto> productos { get; set; }

        public DbSet<RootProducto> roots { get; set; }


    }
}
