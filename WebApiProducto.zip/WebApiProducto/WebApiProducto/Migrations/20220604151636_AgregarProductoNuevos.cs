﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApiProducto.Migrations
{
    public partial class AgregarProductoNuevos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
